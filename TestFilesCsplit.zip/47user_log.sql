-- Table structure for table `user_log`
--

CREATE TABLE user_log (
  username varchar(50) NOT NULL default '0',
  user_id mediumint(8) NOT NULL default '0',
  time datetime NOT NULL default '0000-00-00 00:00:00',
  result tinyint(1) NOT NULL default '0',
  ip varchar(40) NOT NULL default '',
  PRIMARY KEY  (username,user_id,time),
  KEY username (username)
) TYPE=MyISAM;

--
-- Dumping data for table `user_log`
--


--
