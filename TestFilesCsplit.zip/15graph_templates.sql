-- Table structure for table `graph_templates`
--

CREATE TABLE graph_templates (
  id mediumint(8) unsigned NOT NULL auto_increment,
  hash char(32) NOT NULL default '',
  name char(255) NOT NULL default '',
  PRIMARY KEY  (id),
  KEY name (name)
) TYPE=MyISAM COMMENT='Contains each graph template name.';

--
-- Dumping data for table `graph_templates`
--

INSERT INTO graph_templates VALUES (34,'010b90500e1fc6a05abfd542940584d0','SNMP - OID常规模板');
INSERT INTO graph_templates VALUES (2,'5deb0d66c81262843dce5f3861be9966','接口 - 流量 (位/秒)');
INSERT INTO graph_templates VALUES (3,'abb5e813c9f1e8cd6fc1e393092ef8cb','ucd/net - 可用磁盘空间');
INSERT INTO graph_templates VALUES (4,'e334bdcf821cd27270a4cc945e80915e','ucd/net - CPU占用');
INSERT INTO graph_templates VALUES (5,'280e38336d77acde4672879a7db823f3','Karlnet - 无线级别');
INSERT INTO graph_templates VALUES (6,'3109d88e6806d2ce50c025541b542499','Karlnet - 无线传输');
INSERT INTO graph_templates VALUES (7,'cf96dfb22b58e08bf101ca825377fa4b','Unix - Ping延迟');
INSERT INTO graph_templates VALUES (8,'9fe8b4da353689d376b99b2ea526cc6b','Unix - 进程');
INSERT INTO graph_templates VALUES (9,'fe5edd777a76d48fc48c11aded5211ef','Unix - 平均负载');
INSERT INTO graph_templates VALUES (10,'63610139d44d52b195cc375636653ebd','Unix - 已登录用户');
INSERT INTO graph_templates VALUES (11,'5107ec0206562e77d965ce6b852ef9d4','ucd/net - 平均负载');
INSERT INTO graph_templates VALUES (12,'6992ed4df4b44f3d5595386b8298f0ec','Linux - 内存使用');
INSERT INTO graph_templates VALUES (13,'be275639d5680e94c72c0ebb4e19056d','ucd/net - 内存使用');
INSERT INTO graph_templates VALUES (14,'f17e4a77b8496725dc924b8c35b60036','Netware - 文件系统缓存');
INSERT INTO graph_templates VALUES (15,'46bb77f4c0c69671980e3c60d3f22fa9','Netware - CPU占用');
INSERT INTO graph_templates VALUES (16,'8e77a3036312fd0fda32eaea2b5f141b','Netware - 文件系统活性');
INSERT INTO graph_templates VALUES (17,'5892c822b1bb2d38589b6c27934b9936','Netware - 已登录用户');
INSERT INTO graph_templates VALUES (18,'9a5e6d7781cc1bd6cf24f64dd6ffb423','Cisco - CPU占用');
INSERT INTO graph_templates VALUES (19,'0dd0438d5e6cad6776f79ecaa96fb708','Netware - 卷信息');
INSERT INTO graph_templates VALUES (20,'b18a3742ebea48c6198412b392d757fc','Netware - 目录信息');
INSERT INTO graph_templates VALUES (21,'8e7c8a511652fe4a8e65c69f3d34779d','Unix - 可用磁盘空间');
INSERT INTO graph_templates VALUES (22,'06621cd4a9289417cadcb8f9b5cfba80','接口 - 错误/丢包');
INSERT INTO graph_templates VALUES (23,'e0d1625a1f4776a5294583659d5cee15','接口 - 单播包');
INSERT INTO graph_templates VALUES (24,'10ca5530554da7b73dc69d291bf55d38','接口 - 非单播包');
INSERT INTO graph_templates VALUES (25,'df244b337547b434b486662c3c5c7472','接口 - 流量 (字节/秒)');
INSERT INTO graph_templates VALUES (26,'7489e44466abee8a7d8636cb2cb14a1a','设备MIB - 可用磁盘空间');
INSERT INTO graph_templates VALUES (27,'c6bb62bedec4ab97f9db9fd780bd85a6','设备MIB - CPU占用');
INSERT INTO graph_templates VALUES (28,'e8462bbe094e4e9e814d4e681671ea82','设备MIB - 已登录用户');
INSERT INTO graph_templates VALUES (29,'62205afbd4066e5c4700338841e3901e','设备MIB - 进程');
INSERT INTO graph_templates VALUES (30,'e3780a13b0f7a3f85a44b70cd4d2fd36','Netware - 文件打开');
INSERT INTO graph_templates VALUES (31,'1742b2066384637022d178cc5072905a','接口 - 流量 (位/秒, 百分之95)');
INSERT INTO graph_templates VALUES (32,'13b47e10b2d5db45707d61851f69c52b','接口 - 流量 (位/秒, 总带宽)');
INSERT INTO graph_templates VALUES (33,'8ad6790c22b693680e041f21d62537ac','接口 - 流量 (字节/秒, 总带宽)');

--
