-- Table structure for table `graph_tree_items`
--

CREATE TABLE graph_tree_items (
  id mediumint(8) unsigned NOT NULL auto_increment,
  graph_tree_id smallint(5) unsigned NOT NULL default '0',
  local_graph_id mediumint(8) unsigned NOT NULL default '0',
  rra_id smallint(8) unsigned NOT NULL default '0',
  title varchar(255) default NULL,
  host_id mediumint(8) unsigned NOT NULL default '0',
  order_key varchar(100) NOT NULL default '0',
  host_grouping_type tinyint(3) unsigned NOT NULL default '1',
  sort_children_type tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (id),
  KEY graph_tree_id (graph_tree_id),
  KEY host_id (host_id),
  KEY local_graph_id (local_graph_id),
  KEY order_key (order_key)
) TYPE=MyISAM;

--
-- Dumping data for table `graph_tree_items`
--

INSERT INTO graph_tree_items VALUES (7,1,0,0,'',1,'001000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',1,1);

--
