-- Table structure for table `version`
--

CREATE TABLE version (
  cacti char(20) default NULL
) TYPE=MyISAM;

--
-- Dumping data for table `version`
--

INSERT INTO version VALUES ('new_install');
