-- Table structure for table `host_graph`
--

CREATE TABLE host_graph (
  host_id mediumint(8) unsigned NOT NULL default '0',
  graph_template_id mediumint(8) unsigned NOT NULL default '0',
  PRIMARY KEY  (host_id,graph_template_id)
) TYPE=MyISAM;

--
-- Dumping data for table `host_graph`
--

INSERT INTO host_graph VALUES (1,8);
INSERT INTO host_graph VALUES (1,9);
INSERT INTO host_graph VALUES (1,10);
INSERT INTO host_graph VALUES (1,12);

--
