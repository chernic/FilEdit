-- Table structure for table `poller`
--

CREATE TABLE poller (
  id smallint(5) unsigned NOT NULL auto_increment,
  hostname varchar(250) NOT NULL default '',
  ip_address int(11) unsigned NOT NULL default '0',
  last_update datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `poller`
--


--
