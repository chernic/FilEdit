-- Table structure for table `poller_command`
--

CREATE TABLE poller_command (
  poller_id smallint(5) unsigned NOT NULL default '0',
  time datetime NOT NULL default '0000-00-00 00:00:00',
  action tinyint(3) unsigned NOT NULL default '0',
  command varchar(200) NOT NULL default '',
  PRIMARY KEY  (poller_id,action,command)
) TYPE=MyISAM;

--
-- Dumping data for table `poller_command`
--


--
