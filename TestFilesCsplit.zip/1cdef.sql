-- Table structure for table `cdef`
--

CREATE TABLE cdef (
  id mediumint(8) unsigned NOT NULL auto_increment,
  hash varchar(32) NOT NULL default '',
  name varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `cdef`
--

INSERT INTO cdef VALUES (3,'3d352eed9fa8f7b2791205b3273708c7','构建反向栈');
INSERT INTO cdef VALUES (4,'e961cc8ec04fda6ed4981cf5ad501aa5','构建每五分钟');
INSERT INTO cdef VALUES (12,'f1ac79f05f255c02f914c920f1038c54','汇总所有数据源');
INSERT INTO cdef VALUES (2,'73f95f8b77b5508157d64047342c421e','转换字节至位');
INSERT INTO cdef VALUES (14,'634a23af5e78af0964e8d33b1a4ed26b','乘1024');
INSERT INTO cdef VALUES (15,'068984b5ccdfd2048869efae5166f722','汇总所有数据源,乘1024');

--
