-- Table structure for table `data_local`
--

CREATE TABLE data_local (
  id mediumint(8) unsigned NOT NULL auto_increment,
  data_template_id mediumint(8) unsigned NOT NULL default '0',
  host_id mediumint(8) unsigned NOT NULL default '0',
  snmp_query_id mediumint(8) NOT NULL default '0',
  snmp_index varchar(255) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `data_local`
--

INSERT INTO data_local VALUES (3,13,1,0,'');
INSERT INTO data_local VALUES (4,15,1,0,'');
INSERT INTO data_local VALUES (5,11,1,0,'');
INSERT INTO data_local VALUES (6,17,1,0,'');
INSERT INTO data_local VALUES (7,16,1,0,'');

--
