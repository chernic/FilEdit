-- Table structure for table `graph_templates_graph`
--

CREATE TABLE graph_templates_graph (
  id mediumint(8) unsigned NOT NULL auto_increment,
  local_graph_template_graph_id mediumint(8) unsigned NOT NULL default '0',
  local_graph_id mediumint(8) unsigned NOT NULL default '0',
  graph_template_id mediumint(8) unsigned NOT NULL default '0',
  t_image_format_id char(2) default '0',
  image_format_id tinyint(1) NOT NULL default '0',
  t_title char(2) default '0',
  title varchar(255) NOT NULL default '',
  title_cache varchar(255) NOT NULL default '',
  t_height char(2) default '0',
  height mediumint(8) NOT NULL default '0',
  t_width char(2) default '0',
  width mediumint(8) NOT NULL default '0',
  t_upper_limit char(2) default '0',
  upper_limit varchar(20) NOT NULL default '0',
  t_lower_limit char(2) default '0',
  lower_limit varchar(20) NOT NULL default '0',
  t_vertical_label char(2) default '0',
  vertical_label varchar(200) default NULL,
  t_slope_mode char(2) default '0',
  slope_mode char(2) default 'on',
  t_auto_scale char(2) default '0',
  auto_scale char(2) default NULL,
  t_auto_scale_opts char(2) default '0',
  auto_scale_opts tinyint(1) NOT NULL default '0',
  t_auto_scale_log char(2) default '0',
  auto_scale_log char(2) default NULL,
  t_scale_log_units char(2) default '0',
  scale_log_units char(2) default NULL,
  t_auto_scale_rigid char(2) default '0',
  auto_scale_rigid char(2) default NULL,
  t_auto_padding char(2) default '0',
  auto_padding char(2) default NULL,
  t_base_value char(2) default '0',
  base_value mediumint(8) NOT NULL default '0',
  t_grouping char(2) default '0',
  grouping char(2) NOT NULL default '',
  t_export char(2) default '0',
  export char(2) default NULL,
  t_unit_value char(2) default '0',
  unit_value varchar(20) default NULL,
  t_unit_exponent_value char(2) default '0',
  unit_exponent_value varchar(5) NOT NULL default '',
  PRIMARY KEY  (id),
  KEY local_graph_id (local_graph_id),
  KEY graph_template_id (graph_template_id),
  KEY title_cache (title_cache)
) TYPE=MyISAM COMMENT='Stores the actual graph data.';

--
-- Dumping data for table `graph_templates_graph`
--

INSERT INTO graph_templates_graph VALUES (2,0,0,2,'',1,'on','|host_description| - 流量','','',120,'',500,'','100','','0','','位/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (3,0,0,3,'',1,'on','|host_description| - 硬盘空间','','',120,'',500,'','100','','0','','字节','0','on','','on','',2,'','','0','','','on','','on','',1024,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (4,0,0,4,'',1,'','|host_description| - CPU占用','','',120,'',500,'','100','','0','','百分比','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (5,0,0,5,'',1,'on','|host_description| - 无线级别','','',120,'',500,'','100','','0','','百分比','0','on','','','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (6,0,0,6,'',1,'on','|host_description| - 无线传输','','',120,'',500,'','100','','0','','传输','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (7,0,0,7,'',1,'','|host_description| - Ping延迟','','',120,'',500,'','100','','0','','毫秒','0','on','','on','',2,'','','0','','','','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (8,0,0,8,'',1,'','|host_description| - 进程','','',120,'',500,'','100','','0','','进程','0','on','','on','',2,'','','0','','','','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (9,0,0,9,'',1,'','|host_description| - 平均负载','','',120,'',500,'','100','','0','','在运行队例中的进程','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','0');
INSERT INTO graph_templates_graph VALUES (10,0,0,10,'',1,'','|host_description| - 已登录用户','','',120,'',500,'','100','','0','','用户','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (11,0,0,11,'',1,'','|host_description| - 平均负载','','',120,'',500,'','100','','0','','在运行队例中的进程','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','0');
INSERT INTO graph_templates_graph VALUES (12,0,0,12,'',1,'','|host_description| - 内存使用','','',120,'',500,'','100','','0','','千字节','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (13,0,0,13,'',1,'','|host_description| - 内存使用','','',120,'',500,'','100','','0','','字节','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (14,0,0,14,'',1,'','|host_description| - 文件系统缓存','','',120,'',500,'','100','','0','','缓存检测/命中','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (15,0,0,15,'',1,'','|host_description| - CPU占用','','',120,'',500,'','100','','0','','百分比','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (16,0,0,16,'',1,'','|host_description| - 文件系统活性','','',120,'',500,'','100','','0','','读/写每秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (17,0,0,17,'',1,'','|host_description| - 已登录用户','','',120,'',500,'','100','','0','','用户','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (18,0,0,18,'',1,'','|host_description| - CPU占用','','',120,'',500,'','100','','0','','百分比','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (19,0,0,19,'',1,'on','|host_description| - 卷信息','','',120,'',500,'','100','','0','','字节','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (20,0,0,20,'',1,'','|host_description| - 目录信息','','',120,'',500,'','100','','0','','目录入口','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (21,0,0,21,'',1,'on','|host_description| - 可用磁盘空间','','',120,'',500,'','100','','0','','字节','0','on','','on','',2,'','','0','','','on','','on','',1024,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (22,0,0,22,'',1,'on','|host_description| - 错误/丢包','','',120,'',500,'','100','','0','','错误/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (23,0,0,23,'',1,'on','|host_description| - 单播包','','',120,'',500,'','100','','0','','包/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (24,0,0,24,'',1,'on','|host_description| - 非单播包','','',120,'',500,'','100','','0','','包/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (25,0,0,25,'',1,'on','|host_description| - 流量','','',120,'',500,'','100','','0','','字节/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (34,0,0,26,'',1,'on','|host_description| - 可用磁盘空间','','',120,'',500,'','100','','0','','字节','0','on','','on','',2,'','','0','','','on','','on','',1024,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (35,0,0,27,'',1,'on','|host_description| - CPU占用','','',120,'',500,'','100','','0','','百分比','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (36,0,0,28,'',1,'','|host_description| - 已登录用户','','',120,'',500,'','100','','0','','用户','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (37,0,0,29,'',1,'','|host_description| - 进程','','',120,'',500,'','100','','0','','进程','0','on','','on','',2,'','','0','','','','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (38,12,1,12,'0',1,'0','|host_description| - 内存使用','本机 - 内存使用','0',120,'0',500,'0','100','0','0','0','千字节','0','on','0','on','0',2,'0','','0','','0','on','0','on','0',1000,'0','','0','on','0','','0','');
INSERT INTO graph_templates_graph VALUES (39,9,2,9,'0',1,'0','|host_description| - 平均负载','本机 - 平均负载','0',120,'0',500,'0','100','0','0','0','在运行队例中的进程','0','on','0','on','0',2,'0','','0','','0','on','0','on','0',1000,'0','','0','on','0','','0','0');
INSERT INTO graph_templates_graph VALUES (40,10,3,10,'0',1,'0','|host_description| - 已登录用户','本机 - 已登录用户','0',120,'0',500,'0','100','0','0','0','用户','0','on','0','on','0',2,'0','','0','','0','on','0','on','0',1000,'0','','0','on','0','','0','');
INSERT INTO graph_templates_graph VALUES (41,8,4,8,'0',1,'0','|host_description| - 进程','本机 - 进程','0',120,'0',500,'0','100','0','0','0','进程','0','on','0','on','0',2,'0','','0','','0','','0','on','0',1000,'0','','0','on','0','','0','');
INSERT INTO graph_templates_graph VALUES (42,0,0,30,'',1,'','|host_description| - 文件打开','','',120,'',500,'','100','','0','','文件','0','on','','on','',2,'','','0','','','','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (43,0,0,31,'',1,'on','|host_description| - 流量','','',120,'',500,'','100','','0','','位/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (44,0,0,32,'',1,'on','|host_description| - 流量','','',120,'',500,'','100','','0','','位/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (45,0,0,33,'',1,'on','|host_description| - 流量','','',120,'',500,'','100','','0','','字节/秒','0','on','','on','',2,'','','0','','','on','','on','',1000,'0','','','on','','','','');
INSERT INTO graph_templates_graph VALUES (47,0,0,34,'',1,'on','|host_description| -','','',120,'',500,'','100','','0','on','','0','on','','on','',2,'','','0','','','','','on','',1000,'0','','','on','','','','');

--
