-- Table structure for table `poller_item`
--

CREATE TABLE poller_item (
  local_data_id mediumint(8) unsigned NOT NULL default '0',
  poller_id smallint(5) unsigned NOT NULL default '0',
  host_id mediumint(8) NOT NULL default '0',
  action tinyint(2) unsigned NOT NULL default '1',
  hostname varchar(250) NOT NULL default '',
  snmp_community varchar(100) NOT NULL default '',
  snmp_version tinyint(1) unsigned NOT NULL default '0',
  snmp_username varchar(50) NOT NULL default '',
  snmp_password varchar(50) NOT NULL default '',
  snmp_auth_protocol varchar(5) NOT NULL default '',
  snmp_priv_passphrase varchar(200) NOT NULL default '',
  snmp_priv_protocol varchar(6) NOT NULL default '',
  snmp_context varchar(64) default '',
  snmp_port mediumint(5) unsigned NOT NULL default '161',
  snmp_timeout mediumint(8) unsigned NOT NULL default '0',
  rrd_name varchar(19) NOT NULL default '',
  rrd_path varchar(255) NOT NULL default '',
  rrd_num tinyint(2) unsigned NOT NULL default '0',
  rrd_step mediumint(8) NOT NULL default '300',
  rrd_next_step mediumint(8) NOT NULL default '0',
  arg1 TEXT default NULL,
  arg2 varchar(255) default NULL,
  arg3 varchar(255) default NULL,
  PRIMARY KEY  (local_data_id,rrd_name),
  KEY local_data_id (local_data_id),
  KEY host_id (host_id),
  KEY rrd_next_step (rrd_next_step),
  KEY action (action)
) TYPE=MyISAM;

--
-- Dumping data for table `poller_item`
--


--
