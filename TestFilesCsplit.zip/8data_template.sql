-- Table structure for table `data_template`
--

CREATE TABLE data_template (
  id mediumint(8) unsigned NOT NULL auto_increment,
  hash varchar(32) NOT NULL default '',
  name varchar(150) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `data_template`
--

INSERT INTO data_template VALUES (3,'c8a8f50f5f4a465368222594c5709ede','ucd/net - 硬盘空间');
INSERT INTO data_template VALUES (4,'cdfed2d401723d2f41fc239d4ce249c7','ucd/net - CPU - 系统占用');
INSERT INTO data_template VALUES (5,'a27e816377d2ac6434a87c494559c726','ucd/net - CPU - 用户占用');
INSERT INTO data_template VALUES (6,'c06c3d20eccb9598939dc597701ff574','ucd/net - CPU - Nice占用');
INSERT INTO data_template VALUES (7,'a14f2d6f233b05e64263ff03a5b0b386','Karlnet - 干扰级别');
INSERT INTO data_template VALUES (8,'def1a9019d888ed2ad2e106aa9595ede','Karlnet - 信号级别');
INSERT INTO data_template VALUES (9,'513a99ae3c9c4413609c1534ffc36eab','Karlnet - 无线传输');
INSERT INTO data_template VALUES (10,'77404ae93c9cc410f1c2c717e7117378','Karlnet - 无线重传');
INSERT INTO data_template VALUES (11,'9e72511e127de200733eb502eb818e1d','Unix - 平均负载');
INSERT INTO data_template VALUES (13,'dc33aa9a8e71fb7c61ec0e7a6da074aa','Linux - 内存 - 剩余');
INSERT INTO data_template VALUES (15,'41f55087d067142d702dd3c73c98f020','Linux - 内存 - 剩余交换空间');
INSERT INTO data_template VALUES (16,'9b8c92d3c32703900ff7dd653bfc9cd8','Unix - 进程');
INSERT INTO data_template VALUES (17,'c221c2164c585b6da378013a7a6a2c13','Unix - 已登录用户');
INSERT INTO data_template VALUES (18,'a30a81cb1de65b52b7da542c8df3f188','Unix - Ping设备');
INSERT INTO data_template VALUES (19,'0de466a1b81dfe581d44ac014b86553a','Netware - 用户总数');
INSERT INTO data_template VALUES (20,'bbe2da0708103029fbf949817d3a4537','Netware - 登录总数');
INSERT INTO data_template VALUES (22,'e4ac5d5fe73e3c773671c6d0498a8d9d','Netware - 文件系统读');
INSERT INTO data_template VALUES (23,'f29f8c998425eedd249be1e7caf90ceb','Netware - 文件系统写');
INSERT INTO data_template VALUES (24,'7a6216a113e19881e35565312db8a371','Netware - 缓存检测');
INSERT INTO data_template VALUES (25,'1dbd1251c8e94b334c0e6aeae5ca4b8d','Netware - 缓存命中');
INSERT INTO data_template VALUES (26,'1a4c5264eb27b5e57acd3160af770a61','Netware - 文件打开');
INSERT INTO data_template VALUES (27,'e9def3a0e409f517cb804dfeba4ccd90','Cisco路由 - 5分钟CPU');
INSERT INTO data_template VALUES (30,'9b82d44eb563027659683765f92c9757','ucd/net - 平均负载 - 1 分钟');
INSERT INTO data_template VALUES (31,'87847714d19f405ff3c74f3341b3f940','ucd/net - 平均负载 - 5 分钟');
INSERT INTO data_template VALUES (32,'308ac157f24e2763f8cd828a80b3e5ff','ucd/net - 平均负载 - 15 分钟');
INSERT INTO data_template VALUES (33,'797a3e92b0039841b52e441a2823a6fb','ucd/net - 内存 - 缓冲');
INSERT INTO data_template VALUES (34,'fa15932d3cab0da2ab94c69b1a9f5ca7','ucd/net - 内存 - 剩余');
INSERT INTO data_template VALUES (35,'6ce4ab04378f9f3b03ee0623abb6479f','Netware - 卷');
INSERT INTO data_template VALUES (36,'03060555fab086b8412bbf9951179cd9','Netware - 目录入口');
INSERT INTO data_template VALUES (37,'e4ac6919d4f6f21ec5b281a1d6ac4d4e','Unix - 硬盘空间');
INSERT INTO data_template VALUES (38,'36335cd98633963a575b70639cd2fdad','接口 - 错误/丢包');
INSERT INTO data_template VALUES (39,'2f654f7d69ac71a5d56b1db8543ccad3','接口 - 单播包');
INSERT INTO data_template VALUES (40,'c84e511401a747409053c90ba910d0fe','接口 - 非单播包');
INSERT INTO data_template VALUES (41,'6632e1e0b58a565c135d7ff90440c335','接口 - 流量');
INSERT INTO data_template VALUES (42,'1d17325f416b262921a0b55fe5f7e31d','Netware - CPU占用');
INSERT INTO data_template VALUES (43,'d814fa3b79bd0f8933b6e0834d3f16d0','设备 MIB - 硬盘空间');
INSERT INTO data_template VALUES (44,'f6e7d21c19434666bbdac00ccef9932f','设备 MIB - CPU占用');
INSERT INTO data_template VALUES (45,'f383db441d1c246cff8482f15e184e5f','设备 MIB - 进程');
INSERT INTO data_template VALUES (46,'2ef027cc76d75720ee5f7a528f0f1fda','设备 MIB - 已登录用户');
INSERT INTO data_template VALUES (47,'a274deec1f78654dca6c446ba75ebca4','ucd/net - 内存 - 缓存');
INSERT INTO data_template VALUES (48,'d429e4a6019c91e6e84562593c1968ca','SNMP - OID常规模板');

--
