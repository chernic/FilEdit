-- Table structure for table `graph_template_input`
--

CREATE TABLE graph_template_input (
  id mediumint(8) unsigned NOT NULL auto_increment,
  hash varchar(32) NOT NULL default '',
  graph_template_id mediumint(8) unsigned NOT NULL default '0',
  name varchar(255) NOT NULL default '',
  description text,
  column_name varchar(50) NOT NULL default '',
  PRIMARY KEY  (id)
) TYPE=MyISAM COMMENT='Stores the names for graph item input groups.';

--
-- Dumping data for table `graph_template_input`
--

INSERT INTO graph_template_input VALUES (3,'e9d4191277fdfd7d54171f153da57fb0',2,'输入数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (4,'7b361722a11a03238ee8ab7ce44a1037',2,'输出数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (5,'b33eb27833614056e06ee5952c3e0724',3,'可用磁盘空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (6,'ef8799e63ee00e8904bcc4228015784a',3,'已用磁盘空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (7,'2662ef4fbb0bf92317ffd42c7515af37',5,'信号级别数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (8,'a6edef6624c796d3a6055305e2e3d4bf',5,'干扰级别数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (9,'b0e902db1875e392a9d7d69bfbb13515',5,'信号级别颜色','','color_id');
INSERT INTO graph_template_input VALUES (10,'24632b1d4a561e937225d0a5fbe65e41',5,'干扰级别颜色','','color_id');
INSERT INTO graph_template_input VALUES (11,'6d078f1d58b70ad154a89eb80fe6ab75',6,'传输数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (12,'878241872dd81c68d78e6ff94871d97d',6,'重传数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (13,'f8fcdc3a3f0e8ead33bd9751895a3462',6,'传输颜色','','color_id');
INSERT INTO graph_template_input VALUES (14,'394ab4713a34198dddb5175aa40a2b4a',6,'重传颜色','','color_id');
INSERT INTO graph_template_input VALUES (15,'433f328369f9569446ddc59555a63eb8',7,'Ping设备数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (16,'a1a91c1514c65152d8cb73522ea9d4e6',7,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (17,'2fb4deb1448379b27ddc64e30e70dc42',7,'图例文本','','text_format');
INSERT INTO graph_template_input VALUES (18,'592cedd465877bc61ab549df688b0b2a',8,'进程数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (19,'1d51dbabb200fcea5c4b157129a75410',8,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (20,'8cb8ed3378abec21a1819ea52dfee6a3',9,'1分钟数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (21,'5dfcaf9fd771deb8c5430bce1562e371',9,'5分钟数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (22,'6f3cc610315ee58bc8e0b1f272466324',9,'15分钟数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (23,'b457a982bf46c6760e6ef5f5d06d41fb',10,'已登录用户数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (24,'bd4a57adf93c884815b25a8036b67f98',10,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (25,'d7cdb63500c576e0f9f354de42c6cf3a',11,'1分钟数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (26,'a23152f5ec02e7762ca27608c0d89f6c',11,'5分钟数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (27,'2cc5d1818da577fba15115aa18f64d85',11,'15分钟数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (30,'6273c71cdb7ed4ac525cdbcf6180918c',12,'剩余数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (31,'5e62dbea1db699f1bda04c5863e7864d',12,'交换空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (32,'4d52e112a836d4c9d451f56602682606',4,'系统(CPU)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (33,'f0310b066cc919d2f898b8d1ebf3b518',4,'用户(CPU)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (34,'d9eb6b9eb3d7dd44fd14fdefb4096b54',4,'Nice(CPU)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (35,'f45def7cad112b450667aa67262258cb',13,'内存剩余数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (36,'f8c361a8c8b7ad80e8be03ba7ea5d0d6',13,'内存缓冲数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (37,'03d11dce695963be30bd744bd6cbac69',14,'缓存命中数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (38,'9cbc515234779af4bf6cdf71a81c556a',14,'缓存检测数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (39,'2c4d561ee8132a8dda6de1104336a6ec',15,'CPU占用数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (40,'6e1cf7addc0cc419aa903552e3eedbea',16,'文件系统读数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (41,'7ea2aa0656f7064d25a36135dd0e9082',16,'文件系统写数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (42,'63480bca78a38435f24a5b5d5ed050d7',17,'当前登录数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (44,'31fed1f9e139d4897d0460b10fb7be94',15,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (45,'bb9d83a02261583bc1f92d9e66ea705d',18,'CPU占用数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (46,'51196222ed37b44236d9958116028980',18,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (47,'fd26b0f437b75715d6dff983e7efa710',19,'剩余空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (48,'a463dd46862605c90ea60ccad74188db',19,'总空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (49,'9977dd7a41bcf0f0c02872b442c7492e',19,'可释放空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (51,'a7a69bbdf6890d6e6eaa7de16e815ec6',20,'已用目录入口数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (52,'0072b613a33f1fae5ce3e5903dec8fdb',20,'可用目录入口数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (53,'940beb0f0344e37f4c6cdfc17d2060bc',21,'可用磁盘空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (54,'7b0674dd447a9badf0d11bec688028a8',21,'已用磁盘空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (55,'fa83cd3a3b4271b644cb6459ea8c35dc',22,'丢包(输入)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (56,'7946e8ee1e38a65462b85e31a15e35e5',22,'错误(输入)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (57,'00ae916640272f5aca54d73ae34c326b',23,'单播包(输出)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (58,'1bc1652f82488ebfb7242c65d2ffa9c7',23,'单播包(输入)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (59,'e3177d0e56278de320db203f32fb803d',24,'非单播包(输入)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (60,'4f20fba2839764707f1c3373648c5fef',24,'非单播包(输出)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (61,'e5acdd5368137c408d56ecf55b0e077c',22,'丢包(输出)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (62,'a028e586e5fae667127c655fe0ac67f0',22,'错误(输出)数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (63,'2764a4f142ba9fd95872106a1b43541e',25,'输入数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (64,'f73f7ddc1f4349356908122093dbfca2',25,'输出数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (65,'86bd8819d830a81d64267761e1fd8ec4',26,'总磁盘空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (66,'6c8967850102202de166951e4411d426',26,'已用磁盘空间数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (67,'bdad718851a52b82eca0a310b0238450',27,'CPU占用数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (68,'e7b578e12eb8a82627557b955fd6ebd4',27,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (69,'37d09fb7ce88ecec914728bdb20027f3',28,'已登录用户数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (70,'699bd7eff7ba0c3520db3692103a053d',28,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (71,'df905e159d13a5abed8a8a7710468831',29,'进程数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (72,'8ca9e3c65c080dbf74a59338d64b0c14',29,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (73,'69ad68fc53af03565aef501ed5f04744',30,'文件打开数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (74,'562726cccdb67d5c6941e9e826ef4ef5',31,'输入数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (75,'82426afec226f8189c8928e7f083f80f',31,'输出数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (76,'69a23877302e7d142f254b208c58b596',32,'输入数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (77,'f28013abf8e5813870df0f4111a5e695',32,'输出数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (78,'8644b933b6a09dde6c32ff24655eeb9a',33,'输出数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (79,'49c4b4800f3e638a6f6bb681919aea80',33,'输入数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (80,'e0b395be8db4f7b938d16df7ae70065f',13,'缓存数据源','','task_item_id');
INSERT INTO graph_template_input VALUES (81,'2dca37011521501b9c2b705d080db750',34,'数据源[snmp_oid]',NULL,'task_item_id');
INSERT INTO graph_template_input VALUES (82,'b8d8ade5f5f3dd7b12f8cc56bbb4083e',34,'图例颜色','','color_id');
INSERT INTO graph_template_input VALUES (83,'ac2355b4895c37e14df827f969f31c12',34,'图例文本','','text_format');

--
