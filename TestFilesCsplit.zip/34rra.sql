-- Table structure for table `rra`
--

CREATE TABLE rra (
  id mediumint(8) unsigned NOT NULL auto_increment,
  hash varchar(32) NOT NULL default '',
  name varchar(100) NOT NULL default '',
  x_files_factor double NOT NULL default '0.1',
  steps mediumint(8) default '1',
  rows int(12) NOT NULL default '600',
  timespan int(12) unsigned NOT NULL default '0',
  PRIMARY KEY  (id)
) TYPE=MyISAM;

--
-- Dumping data for table `rra`
--

INSERT INTO rra VALUES (1,'c21df5178e5c955013591239eb0afd46','日 (5分钟平均)',0.5,1,600,86400);
INSERT INTO rra VALUES (2,'0d9c0af8b8acdc7807943937b3208e29','周 (30分钟平均)',0.5,6,700,604800);
INSERT INTO rra VALUES (3,'6fc2d038fb42950138b0ce3e9874cc60','月 (2小时平均)',0.5,24,775,2678400);
INSERT INTO rra VALUES (4,'e36f3adb9f152adfa5dc50fd2b23337e','年 (1天平均)',0.5,288,797,33053184);
INSERT INTO rra VALUES (5,'283ea2bf1634d92ce081ec82a634f513','小时 (1分钟平均)',0.5,1,500,14400);

--
