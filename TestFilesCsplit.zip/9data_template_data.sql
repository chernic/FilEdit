-- Table structure for table `data_template_data`
--

CREATE TABLE data_template_data (
  id mediumint(8) unsigned NOT NULL auto_increment,
  local_data_template_data_id mediumint(8) unsigned NOT NULL default '0',
  local_data_id mediumint(8) unsigned NOT NULL default '0',
  data_template_id mediumint(8) unsigned NOT NULL default '0',
  data_input_id mediumint(8) unsigned NOT NULL default '0',
  t_name char(2) default NULL,
  name varchar(250) NOT NULL default '',
  name_cache varchar(255) NOT NULL default '',
  data_source_path varchar(255) default NULL,
  t_active char(2) default NULL,
  active char(2) default NULL,
  t_rrd_step char(2) default NULL,
  rrd_step mediumint(8) unsigned NOT NULL default '0',
  t_rra_id char(2) default NULL,
  PRIMARY KEY  (id),
  KEY local_data_id (local_data_id),
  KEY data_template_id (data_template_id)
) TYPE=MyISAM;

--
-- Dumping data for table `data_template_data`
--

INSERT INTO data_template_data VALUES (3,0,0,3,2,'on','|host_description| - 硬盘空间','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (4,0,0,4,1,'','|host_description| - CPU - 系统占用','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (5,0,0,5,1,'','|host_description| - CPU - 用户占用','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (6,0,0,6,1,'','|host_description| - CPU - Nice占用','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (7,0,0,7,2,'on','|host_description| - 干扰级别','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (8,0,0,8,2,'on','|host_description| - 信号级别','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (9,0,0,9,2,'on','|host_description| - 无线传输','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (10,0,0,10,2,'on','|host_description| - 无线重传','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (11,0,0,11,4,'','|host_description| - 平均负载','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (13,0,0,13,6,'','|host_description| - 内存 - 剩余','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (15,0,0,15,6,'','|host_description| - 内存 - 剩余交换空间','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (16,0,0,16,7,'','|host_description| - 进程','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (17,0,0,17,5,'','|host_description| - 已登录用户','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (18,0,0,18,10,'','|host_description| - Ping设备','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (19,0,0,19,1,'','|host_description| - 用户总数','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (20,0,0,20,1,'','|host_description| - 登录总数','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (22,0,0,22,1,'','|host_description| - 文件系统读','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (23,0,0,23,1,'','|host_description| - 文件系统写','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (24,0,0,24,1,'','|host_description| - 缓存检测','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (25,0,0,25,1,'','|host_description| - 缓存命中','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (26,0,0,26,1,'','|host_description| - 文件打开','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (27,0,0,27,1,'','|host_description| - 5分钟CPU','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (30,0,0,30,1,'','|host_description| - 平均负载 - 1 分钟','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (31,0,0,31,1,'','|host_description| - 平均负载 - 5 分钟','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (32,0,0,32,1,'','|host_description| - 平均负载 - 15 分钟','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (33,0,0,33,1,'','|host_description| - 内存 - 缓冲','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (34,0,0,34,1,'','|host_description| - 内存 - 剩余','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (35,0,0,35,2,'on','|host_description| - 卷','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (36,0,0,36,2,'on','|host_description| - 目录入口','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (37,0,0,37,11,'on','|host_description| - 硬盘空间','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (38,0,0,38,2,'on','|host_description| - 错误/丢包','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (39,0,0,39,2,'on','|host_description| - 单播包','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (40,0,0,40,2,'on','|host_description| - 非单播包','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (41,0,0,41,2,'on','|host_description| - 流量','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (55,0,0,42,2,'','|host_description| - CPU占用','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (56,0,0,43,12,'','|host_description| - 硬盘空间','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (57,0,0,44,12,'','|host_description| - CPU占用','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (58,0,0,45,1,'','|host_description| - 进程','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (59,0,0,46,1,'','|host_description| - 已登录用户','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (62,13,3,13,6,NULL,'|host_description| - 内存 - 剩余','本机 - 内存 - 剩余','<path_rra>/localhost_mem_buffers_3.rrd',NULL,'on',NULL,300,NULL);
INSERT INTO data_template_data VALUES (63,15,4,15,6,NULL,'|host_description| - 内存 - 剩余交换空间','本机 - 内存 - 剩余交换空间','<path_rra>/localhost_mem_swap_4.rrd',NULL,'on',NULL,300,NULL);
INSERT INTO data_template_data VALUES (64,11,5,11,4,NULL,'|host_description| - 平均负载','本机 - 平均负载','<path_rra>/localhost_load_1min_5.rrd',NULL,'on',NULL,300,NULL);
INSERT INTO data_template_data VALUES (65,17,6,17,5,NULL,'|host_description| - 已登录用户','本机 - 已登录用户','<path_rra>/localhost_users_6.rrd',NULL,'on',NULL,300,NULL);
INSERT INTO data_template_data VALUES (66,16,7,16,7,NULL,'|host_description| - 进程','本机 - 进程','<path_rra>/localhost_proc_7.rrd',NULL,'on',NULL,300,NULL);
INSERT INTO data_template_data VALUES (68,0,0,47,1,'','|host_description| - 内存 - 缓存','',NULL,'','on','',300,'');
INSERT INTO data_template_data VALUES (69,0,0,48,1,'on','|host_description| -','',NULL,'','on','',300,'');

--
